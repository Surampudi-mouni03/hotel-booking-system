import cv2
import numpy as np
import torch
from torchvision import models, transforms

# Load and preprocess camera image
def preprocess_camera_frame(image_path):
    frame = cv2.imread(image_path)
    if frame is None:
        raise FileNotFoundError(f"Could not load image at {image_path}. Check the file path and ensure it exists.")
    
    # Use updated weights parameter instead of deprecated 'pretrained'
    model = models.detection.fasterrcnn_resnet50_fpn(weights='FasterRCNN_ResNet50_FPN_Weights.DEFAULT')
    model.eval()
    transform = transforms.Compose([transforms.ToTensor()])
    img = transform(frame).unsqueeze(0)
    with torch.no_grad():
        prediction = model(img)[0]
    
    objects = []
    for label, score, box in zip(prediction['labels'], prediction['scores'], prediction['boxes']):
        if score > 0.5:  # Only confident detections
            objects.append({
                'type': label.item(),  # 1=person, 2=car, etc.
                'box': box.tolist()    # Position in image
            })
    return objects

# Simulate radar data
def preprocess_radar_data():
    return [
        {'type': 2, 'distance': 10.5, 'speed': 5.0},  # Car
        {'type': 1, 'distance': 3.2, 'speed': 1.0}    # Person
    ]

# Fuse camera and radar data
def fuse_sensor_data(camera_objects, radar_objects):
    fused_data = []
    for cam_obj in camera_objects:
        for rad_obj in radar_objects:
            if cam_obj['type'] == rad_obj['type']:  # Match by type
                fused_data.append({
                    'type': rad_obj['type'],
                    'box': cam_obj['box'],
                    'distance': rad_obj['distance'],
                    'speed': rad_obj['speed']
                })
    return fused_data

# Draw detected objects on image
def draw_contours(frame, fused_data):
    if frame is None:
        raise ValueError("Image frame is None. Check image loading.")
    for obj in fused_data:
        x1, y1, x2, y2 = map(int, obj['box'])
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        label = f"{'Car' if obj['type'] == 2 else 'Person'} {obj['distance']}m"
        cv2.putText(frame, label, (x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    return frame

# Decide actions to avoid collisions
def collision_avoidance(fused_data):
    actions = []
    for obj in fused_data:
        if obj['distance'] < 5.0:
            actions.append(f"Brake + Alarm for {'Car' if obj['type'] == 2 else 'Person'} at {obj['distance']}m")
        elif obj['distance'] < 10.0:
            actions.append(f"Alert for {'Car' if obj['type'] == 2 else 'Person'} at {obj['distance']}m")
    return actions

# Run everything
try:
    # Step 2: Preprocess data
    camera_objects = preprocess_camera_frame('C:/Users/Dell/OneDrive/Desktop/ADAS_Assignment/sample_image.jpg')
    radar_objects = preprocess_radar_data()
    print("Camera Objects:", camera_objects)
    print("Radar Objects:", radar_objects)
    
    # Step 3: Fuse and visualize
    fused_data = fuse_sensor_data(camera_objects, radar_objects)
    frame = cv2.imread('C:/Users/Dell/OneDrive/Desktop/ADAS_Assignment/sample_image.jpg')
    output_frame = draw_contours(frame.copy(), fused_data)
    cv2.imwrite('output_detection.jpg', output_frame)
    print("Fused Data:", fused_data)
    
    # Step 4: Decision making
    decisions = collision_avoidance(fused_data)
    for decision in decisions:
        print(decision)

except Exception as e:
    print(f"Error: {e}")