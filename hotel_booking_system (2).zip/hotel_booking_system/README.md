# Hotel Booking System API

This project implements a hotel booking system API using FastAPI, SQLite, and a Retrieval-Augmented Generation (RAG) system for answering questions about booking data. The system processes booking data from a CSV file, stores it in a SQLite database, and provides endpoints to retrieve analytics and answer questions about the data.

## Setup Instructions
1. **Install Python 3.11**:
   - Download Python 3.11.9 from [python.org](https://www.python.org/downloads/release/python-3119/).
   - Install it, ensuring "Add Python 3.11 to PATH" is checked.

2. **Install Required Libraries**:
   - Open a terminal and run:pip install --user pandas fastapi uvicorn numpy sentence-transformers faiss-cpu pydantic
   
3. **Move the Project to a Local Folder**:
- Copy the `hotel_booking_system` folder to `C:\Users\Dell\Desktop` to avoid OneDrive syncing issues.

4. **Run the Script**:
- Open the project folder in VS Code.
- In the terminal, navigate to the project folder:cd C:\Users\Dell\Desktop\hotel_booking_system
- Run the script:python main.py
- The server will start on `http://localhost:8001`.

5. **Test the Endpoints**:
- **Root Endpoint**:
- In a browser, go to `http://localhost:8001/`.
- Expected output: `{"message":"Welcome to the Hotel Booking System API. Available endpoints: /health, /analytics, /ask"}`.
- **Health Check**:
- In a browser, go to `http://localhost:8001/health`.
- Expected output: `{"status": "healthy"}`.
- **Analytics**:
- In a terminal, run:Invoke-WebRequest -Method POST -Uri http://localhost:8001/analytics
- Expected output: Analytics data (e.g., revenue trends, cancellation rate, location distribution).
- **Q&A**:
- In a terminal, run:Invoke-WebRequest -Method POST -Uri http://localhost:8001/ask -ContentType "application/json" -Body '{"text": "What is the average price of a hotel booking?"}'
- Expected output: `{"answer":"Average price: 175.0"}`.

6. **Run Automated Tests (Optional)**:
- Ensure the server (`main.py`) is running on `http://localhost:8001`.
- Open a new terminal in VS Code (click the "+" button in the terminal panel).
- Navigate to the project folder:cd C:\Users\Dell\Desktop\hotel_booking_system
- Run the test script:python test_server.py
- This script automates testing of the API endpoints (e.g., `/ask`, `/health`, `/analytics`). Check the terminal output for test results.
- Note: If `test_server.py` tries to start another server on port 8001, it will cause a port conflict. Ensure `main.py` is the only server running.

## Q&A Evaluation
I tested the `/ask` endpoint with the following questions:

Question                          | Expected Answer                          | Actual Answer                          | Correct?
----------------------------------|------------------------------------------|----------------------------------------|----------
What is the average price of a    | Average price: 175.0                    | {"answer":"Average price: 175.0"}     | Yes
hotel booking?                    |                                          |                                        |
What is the total revenue?        | Total revenue: 450.0                    | {"answer":"Total revenue: 450.0"}     | Yes
What is the cancellation rate?    | Cancellation rate: 33.33333333333333    | {"answer":"Cancellation rate: 33.33333333333333"} | Yes
What is the average lead time?    | Average lead time: 5.0                  | {"answer":"Average lead time: 5.0"}   | Yes
Which locations had the highest   | London had the highest booking          | {"answer":"London had the highest booking cancellations with 1 cancellation(s)."} | Yes
booking cancellations?            | cancellations with 1 cancellation.      |                                        |
What is the most expensive        | The most expensive booking has a        | {"answer":"The most expensive booking has a price of 200.0."} | Yes
booking?                          | price of 200.0.                         |                                        |

### Observations
- The Q&A system initially returned generic responses for most questions (e.g., "Found relevant bookings. Please specify your question for detailed insights.").
- After updating the `RAGSystem.query` method in `main.py` to handle specific questions (e.g., cancellation rate, total revenue, average lead time, highest cancellations, most expensive booking), the system correctly answered 6 out of 6 questions.
- The system continued to perform reliably after resolving port conflicts (changed to port 8001) and adding a root endpoint for better user experience.
- The RAG system (using sentence-transformers and FAISS) is set up but underutilized; it could be enhanced to provide more detailed answers for questions that don’t match predefined conditions, such as queries about specific locations or date ranges.

## Challenges Faced
- **Python Installation**: Initially, Python was not found because it wasn’t added to PATH. I reinstalled Python 3.11 with "Add Python to PATH" enabled.
- **OneDrive Issues**: The project was in a OneDrive folder, causing file access issues. I moved it to a local folder (`C:\Users\Dell\Desktop\hotel_booking_system`).
- **Port Conflicts**: Port 8000 was repeatedly in use by another process, causing errors. I initially resolved this by stopping the conflicting process using `netstat` and `taskkill`, but the issue recurred. I then changed the port to 8001 in `main.py` to avoid further conflicts.
- **PowerShell Commands**: The `curl` command didn’t work in PowerShell; I used `Invoke-WebRequest` instead.
- **Q&A System**: The `/ask` endpoint initially returned generic responses for most questions. I updated the `RAGSystem.query` method to handle specific questions, improving its accuracy.
- **Root Endpoint**: Accessing `http://localhost:8000/` initially returned a 404 error. I added a root endpoint to display a welcome message.

## Additional Notes
- The SQLite database (`booking_data.db`) is generated when `main.py` is run and contains the booking data and precomputed analytics.
- The `test_server.py` script is included to automate testing of the API endpoints. It sends requests to the running server and checks the responses. This is an optional tool for testing and is not required to use the core functionality of the project.
- Future improvements could include adding support for more complex questions (e.g., location-specific or date-specific queries) and expanding the dataset with more bookings.