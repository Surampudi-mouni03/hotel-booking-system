import pandas as pd # type: ignore
import sqlite3
from fastapi import FastAPI, HTTPException # type: ignore
from pydantic import BaseModel # type: ignore
from typing import List, Dict
import uvicorn # type: ignore
from datetime import datetime
import numpy as np # type: ignore
from sentence_transformers import SentenceTransformer # type: ignore
import faiss # type: ignore

# Initialize FastAPI app
app = FastAPI()

# Initialize embedding model for RAG
embedder = SentenceTransformer('all-MiniLM-L6-v2')

# Database setup
def init_db():
    conn = sqlite3.connect('booking_data.db')
    c = conn.cursor()
    
    # Create tables
    c.execute('''CREATE TABLE IF NOT EXISTS bookings
                 (id INTEGER PRIMARY KEY, booking_date TEXT, revenue REAL, 
                  is_canceled INTEGER, location TEXT, lead_time INTEGER, 
                  price REAL)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS analytics
                 (id INTEGER PRIMARY KEY, type TEXT, value TEXT, 
                  last_updated TEXT)''')
    
    conn.commit()
    conn.close()

# Data preprocessing class
class BookingProcessor:
    def __init__(self, csv_path: str):
        self.df = pd.read_csv(csv_path)
        self.preprocess_data()
        self.store_precomputed_insights()

    def preprocess_data(self):
        # Handle missing values
        self.df['revenue'] = self.df['revenue'].fillna(0)
        self.df['is_canceled'] = self.df['is_canceled'].fillna(0)
        self.df['location'] = self.df['location'].fillna('Unknown')
        self.df['lead_time'] = self.df['lead_time'].fillna(0)
        self.df['price'] = self.df['price'].fillna(self.df['price'].mean())
        
        # Convert booking_date to datetime
        self.df['booking_date'] = pd.to_datetime(self.df['booking_date'])

    def store_precomputed_insights(self):
        conn = sqlite3.connect('booking_data.db')
        c = conn.cursor()
        
        # Store raw bookings
        self.df.to_sql('bookings', conn, if_exists='replace', index=False)
        
        # Precompute and store analytics
        # Revenue trends
        revenue_trends = self.df.groupby(self.df['booking_date'].dt.to_period('M'))['revenue'].sum().to_json()
        c.execute("INSERT OR REPLACE INTO analytics (type, value, last_updated) VALUES (?, ?, ?)",
                 ('revenue_trends', revenue_trends, datetime.now().isoformat()))

        # Cancellation rate
        cancel_rate = (self.df['is_canceled'].sum() / len(self.df)) * 100
        c.execute("INSERT OR REPLACE INTO analytics (type, value, last_updated) VALUES (?, ?, ?)",
                 ('cancel_rate', str(cancel_rate), datetime.now().isoformat()))

        # Location distribution
        location_dist = self.df['location'].value_counts().to_json()
        c.execute("INSERT OR REPLACE INTO analytics (type, value, last_updated) VALUES (?, ?, ?)",
                 ('location_distribution', location_dist, datetime.now().isoformat()))

        conn.commit()
        conn.close()

# RAG Implementation
class RAGSystem:
    def __init__(self):
        self.index = None
        self.df = None  # Store the DataFrame for easier access
        self.build_index()

    def build_index(self):
        conn = sqlite3.connect('booking_data.db')
        self.df = pd.read_sql_query("SELECT * FROM bookings", conn)
        conn.close()
        
        # Create embeddings for booking records
        texts = self.df.apply(lambda row: f"Booking on {row['booking_date']} for {row['location']}", axis=1)
        embeddings = embedder.encode(texts.tolist())
        self.index = faiss.IndexFlatL2(embeddings.shape[1])
        self.index.add(embeddings)

    def query(self, question: str) -> str:
        try:
            conn = sqlite3.connect('booking_data.db')
            c = conn.cursor()
            
            # Handle specific question types
            question_lower = question.lower()

            # Question about revenue trends
            if "revenue" in question_lower and "for" in question_lower:
                c.execute("SELECT value FROM analytics WHERE type='revenue_trends'")
                trends = c.fetchone()[0]
                return f"Revenue data: {trends}"
            
            # Question about cancellation rate
            elif "cancellation rate" in question_lower:
                cancel_rate = (self.df['is_canceled'].sum() / len(self.df)) * 100
                return f"Cancellation rate: {cancel_rate}"
            
            # Question about cancellations by location
            elif "cancellations" in question_lower:
                df = pd.read_sql_query("SELECT location, COUNT(*) as cancels FROM bookings WHERE is_canceled=1 GROUP BY location", conn)
                if df.empty:
                    return "No cancellations found in the data."
                result = df.set_index('location')['cancels'].to_dict()
                return f"Cancellations by location: {result}"
            
            # Question about average price
            elif "average price" in question_lower:
                df = pd.read_sql_query("SELECT AVG(price) as avg_price FROM bookings", conn)
                return f"Average price: {df['avg_price'][0]}"
            
            # Question about total revenue
            elif "total revenue" in question_lower:
                total_revenue = self.df['revenue'].sum()
                return f"Total revenue: {total_revenue}"
            
            # Question about average lead time
            elif "average lead time" in question_lower:
                avg_lead_time = self.df['lead_time'].mean()
                return f"Average lead time: {avg_lead_time}"
            
            # Question about highest cancellations
            elif "highest" in question_lower and "cancellations" in question_lower:
                df = pd.read_sql_query("SELECT location, COUNT(*) as cancels FROM bookings WHERE is_canceled=1 GROUP BY location", conn)
                if df.empty:
                    return "No cancellations found in the data."
                max_cancel_location = df.loc[df['cancels'].idxmax()]['location']
                max_cancel_count = df['cancels'].max()
                return f"{max_cancel_location} had the highest booking cancellations with {max_cancel_count} cancellation(s)."
            
            # Question about most expensive booking
            elif "most expensive" in question_lower and "booking" in question_lower:
                max_price = self.df['price'].max()
                return f"The most expensive booking has a price of {max_price}."
            
            # Default RAG response with more context
            else:
                query_embedding = embedder.encode([question])
                D, I = self.index.search(query_embedding, k=5)
                relevant_bookings = self.df.iloc[I[0]]
                summary = f"Found {len(relevant_bookings)} relevant bookings: "
                for _, row in relevant_bookings.iterrows():
                    summary += f"Booking on {row['booking_date']} in {row['location']}, "
                return summary + "Please specify your question for detailed insights."

        except Exception as e:
            return f"Error processing question: {str(e)}"
        finally:
            conn.close()
# Pydantic models for API
class Question(BaseModel):
    text: str

# API Endpoints
@app.post("/analytics")
async def get_analytics():
    conn = sqlite3.connect('booking_data.db')
    c = conn.cursor()
    c.execute("SELECT type, value FROM analytics")
    results = {row[0]: row[1] for row in c.fetchall()}
    conn.close()
    return results

@app.post("/ask")
async def ask_question(question: Question):
    rag = RAGSystem()
    return {"answer": rag.query(question.text)}

@app.get("/health")
async def health_check():
    try:
        conn = sqlite3.connect('booking_data.db')
        conn.close()
        return {"status": "healthy"}
    except:
        raise HTTPException(status_code=500, detail="Database connection failed")
@app.get("/")
async def root():
    return {"message": "Welcome to the Hotel Booking System API. Available endpoints: /health, /analytics, /ask"}

# Initialize system
if __name__ == "__main__":
    print("Step 1: Starting the script...")
    init_db()
    print("Step 2: Database created.")
    processor = BookingProcessor("sample_booking_data.csv")
    print("Step 3: Data loaded.")
    uvicorn.run(app, host="0.0.0.0", port=8001)
    print("Step 4: Server started.")